
import {h} from '../../src/runtime-core/'
describe('h', () => {
    test('should return vnode', () => {
        
        
        
    })
    
    
})