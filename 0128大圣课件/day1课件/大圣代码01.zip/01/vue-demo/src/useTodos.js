import {reactive,ref} from 'vue'

export default function useTodos(){
  let val = ref('')
  let todos = reactive([
        {id:0,title:'吃饭',done:false},
        {id:1,title:'睡觉',done:false},
      ])
  
  function addCounter(){
    todos.push({
        id:todos.length,
        title:val.value,
        done:false
    })
    val.value = ""
  }
  return {val,todos,addCounter}
}
