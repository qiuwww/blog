// 组件任意拆分

import {ref} from 'vue'

export default function useCounter(){
  // ref: countr = 1 // 方言
  let counter = ref(1)
  function addCounter(){
    counter.value+=1
  }
  return {counter, addCounter}
}

// compositon 和hooks有啥区别
// useCounter的命名风格，我就是跟hooks学的