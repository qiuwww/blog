
<template>
  <div>
    <h1>{{x}}:{{double}}</h1>
    <h1 @click="addCounter">{{counter}}</h1>
    <input type="text" v-model="val" @keyup.enter="addTodo">
    <ul>
      <li v-for="todo in todos" :key="todo.id">{{todo.title}}</li>
    </ul>
  </div>
</template>

<script setup>
// element3 欢迎大家关注 我们forkelement2 改造一下
// 为了教育的项目 怎么做组件化

// template 不够动态，语法限制
//   v-if
//   v-for
//   ....定义好的语法
//   好处：有限制，可遍历，优化空间比较大
// 缺点：难看
// return很蛋疼
// 1. tree-shaking 没有用到computed，代码build的时候就会删掉vue3里面computed的代码
// 2. 方便组合  逻辑都是函数，组合优于继承

// 组件可以任意拆分
// 一个新的需求：页面显示鼠标的坐标
// 一个新的需求：累加器
// 渐进式更新：ref api
import {reactive,ref,toRefs} from 'vue'
import useCounter from './useCounter'
import useTodos from './useTodos'
import useMouse from './useMouse'

// vue1只有响应式，项目大了之后，响应式对象太多，导致卡顿
// vue 响应式+vdom
  // 响应式：数据变了通知你
  // vdom:数据变了你不知道哪里变了，算一次diff，才知道变化
  // 是怎么配合的
// 后续靠的响应式通知
// 数据流清晰
let {counter,addCounter} = useCounter() // 组合

let {val,todos,addCounter:addTodo} = useTodos()

let {x,double} = useMouse()

// export default {
    // render(){
      // 也可以用jsx
    // }
//   data(){
//     return{
//       val:'',
//       todos:[
//         {id:0,title:'吃饭',done:false},
//         {id:1,title:'睡觉',done:false},
//       ],
//     }
//   },
//   mixins:['counter','mouse'],
//   // mixinx巨大的问题：命名冲突
//   methods:{
//     addTodo(){
//       // this.xx 是一个黑盒
//       this.todos.push({
//         id:this.todos.length,
//         title:this.val,
//         done:false
//       })
//       this.val = ""
//     }

//   }
// }
</script>
