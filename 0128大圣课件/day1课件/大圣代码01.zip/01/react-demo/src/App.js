import React,{useState} from 'react'

// react没有响应式，纯纯的vdom，计算diff
// 这个vdom树太大了，diff时间经常过16.6ms，会导致卡顿，怎么办
function App() {
  // 这个函数，每次render都会执行
  // hooks是有顺序限制的
  let [counter,setCounter] = useState(0)
  let [num,setNum] = useState(0)
  // jsx就是纯js
  let arr = [1,2,3]
  return (
    <div>
      <h1 onClick={()=>setCounter(counter+1)}>
        {counter}
      </h1>
    </div>
  );
}

export default App;
