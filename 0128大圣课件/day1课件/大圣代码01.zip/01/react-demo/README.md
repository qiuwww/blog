

   1           1
  2 3        2,3,4

  .innerHTML
  appendChild（4）


1,2,3,4   old   
4,3,5,1   new 
diff: 移动4 移动1，删除2，新增5
第三天讲这个算法：最长递增子序列 + 双端预判


响应式主动通知
虚拟dom是被动计算

vue两个怎么配合的？
  根据组件划分，组件之间通过响应式通知，组件内部，通过vdom计算diff

svelte 没有vdom，编译成js

vdom: 用js的object 来描述你的dom节点，跨端


16.6

vue2引入了vdom，使用的是snabbdom的代码，双端预判

2
5
react上来就是干，计算diff
双端预判 减少循环的次数
web这个领域，列表大部分都是插入数据，删除数据，倒序，打乱排序


fiber也就是所谓的时间切片
1. 任务可以切开 利用空闲时间计算
2. diff可以中断

树结构，变成链表

the-super-tiny-compiler

react就是解析jsx => createElement 没有太多的标记

async function xx(){


}
...

<!-- try{
  let ret = await xx()
}catche(e){
  console.log(e)
  直接加上错误通知机智
  把报错通知给后端的统计系统
}

可以考虑写一个webpack的loader来做这个转换 -->




