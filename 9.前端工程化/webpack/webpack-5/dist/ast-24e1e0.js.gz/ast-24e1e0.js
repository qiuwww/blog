!function(){"use strict";console.log("ast-demo.js")}();
//# sourceMappingURL=ast-24e1e0.js.map